# MYREP HUAWEI MANAGEMENT

Aplikasi Android Kotlin untuk mengelola router Huawei melalui jaringan lokal.

## Kondisi saat ini

- Struktur aplikasi Android Kotlin.
- Deteksi gateway Wi-Fi dan input alamat router manual.
- Tes respons HTTP router.
- Percobaan autentikasi keluarga antarmuka Huawei ONT legacy:
  - `POST /asp/GetRandCount.asp` untuk token anti-replay.
  - `POST /login.cgi` dengan `UserName`, password Base64, `Language`, dan `x.X_HW_Token`.
  - Menyimpan cookie sesi di memori aplikasi melalui `CookieManager`.
  - Mencoba mengambil token sesi dari `/html/ssmp/common/GetRandToken.asp`.
- Pemeriksaan beberapa halaman WLAN untuk diagnosis firmware.

## Batas kompatibilitas

Endpoint di atas ditemukan pada beberapa implementasi antarmuka Huawei ONT HG8145V5/EG8145V5, tetapi firmware ISP dapat berbeda. Keberhasilan autentikasi belum dijamin untuk semua HG8145V5. Fitur membaca atau mengubah SSID/password belum dinyatakan selesai sampai diuji pada perangkat target dan struktur respons aslinya diketahui.

## Keamanan

- Kredensial dimasukkan langsung oleh pengguna.
- Password tidak disimpan oleh aplikasi.
- Komunikasi dilakukan ke alamat lokal router. Jangan gunakan pada jaringan atau perangkat yang bukan milik pengguna atau yang tidak diizinkan.
- HTTP lokal dipakai karena sejumlah firmware ONT hanya menyediakan antarmuka tersebut. Jangan memakai aplikasi ini melalui jaringan publik.

## Build APK

Build otomatis tersedia melalui GitHub Actions pada `.github/workflows/build-apk.yml`.

- Workflow berjalan saat ada push ke `main` atau dijalankan manual.
- Output: `app/build/outputs/apk/debug/app-debug.apk`.
- Build belum diverifikasi pada lingkungan lokal karena Android SDK dan Gradle tidak tersedia di lingkungan pengembangan ini.

## Target awal pengujian

Huawei HG8145V5. Catat alamat gateway, versi firmware, hasil login, serta hasil pemeriksaan halaman WLAN untuk menentukan adaptor firmware berikutnya.


## V3: pemeriksaan WLAN read-only

Setelah login dinyatakan memiliki cookie sesi, aplikasi mencoba beberapa halaman WLAN yang umum pada firmware Huawei. Aplikasi hanya memeriksa HTML yang dikembalikan dan mencari input yang namanya mengandung SSID atau field kunci WiFi. Ini adalah diagnostik heuristik, bukan dukungan HG8145V5 yang sudah tervalidasi. Firmware dapat memakai endpoint berbeda, memuat data melalui JavaScript, atau menyamarkan password. Tidak ada konfigurasi router yang diubah.

### Status validasi

- Source V2 telah ditinjau secara statis.
- V3 menambahkan pembacaan halaman WLAN secara read-only dan deteksi field HTML.
- Belum ada unit HG8145V5 yang diuji, sehingga autentikasi, nama SSID, dan password belum terverifikasi.
- Build APK belum dijalankan pada lingkungan ini karena Android SDK/Gradle tidak tersedia. Gunakan workflow GitHub Actions untuk build setelah source diunggah.
