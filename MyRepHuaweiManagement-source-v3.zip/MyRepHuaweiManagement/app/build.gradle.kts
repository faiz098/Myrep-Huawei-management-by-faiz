plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "id.myrep.huaweimanager"
    compileSdk = 35
    defaultConfig {
        applicationId = "id.myrep.huaweimanager"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
