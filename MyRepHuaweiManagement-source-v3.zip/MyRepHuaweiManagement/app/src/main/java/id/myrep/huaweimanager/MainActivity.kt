package id.myrep.huaweimanager

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.net.wifi.WifiManager
import android.graphics.Color
import android.view.ViewGroup
import android.widget.*
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var ipField: EditText
    private lateinit var usernameField: EditText
    private lateinit var passwordField: EditText
    private lateinit var status: TextView
    private lateinit var loginButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(76, 29, 149)
        window.navigationBarColor = Color.BLACK

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(248, 247, 252))
        }
        val scroll = ScrollView(this).apply { addView(page) }
        page.addView(label("MYREP HUAWEI MANAGEMENT", 23, Color.rgb(76, 29, 149), true))
        page.addView(label("Pengelolaan router Huawei melalui jaringan lokal.", 14, Color.DKGRAY))
        page.addView(label("Koneksi router", 19, Color.BLACK, true).apply { setPadding(0, 28, 0, 10) })

        ipField = input("IP router, contoh 192.168.100.1").apply { setText(detectGateway()) }
        page.addView(ipField)
        page.addView(Button(this).apply {
            text = "Deteksi gateway otomatis"
            setOnClickListener {
                val gateway = detectGateway()
                if (gateway.isBlank()) showStatus("Gateway tidak terdeteksi. Sambungkan HP ke WiFi router.")
                else { ipField.setText(gateway); showStatus("Gateway ditemukan: $gateway") }
            }
        })

        page.addView(label("Akun router", 19, Color.BLACK, true).apply { setPadding(0, 24, 0, 10) })
        usernameField = input("Username router")
        passwordField = input("Password router").apply { inputType = 129 }
        page.addView(usernameField)
        page.addView(passwordField)
        page.addView(label("Gunakan akun router milik sendiri atau akun yang diizinkan. Password tidak disimpan dan tidak dikirim ke server luar.", 12, Color.GRAY))

        page.addView(Button(this).apply {
            text = "Uji koneksi router"
            setOnClickListener { testConnection() }
        })
        loginButton = Button(this).apply {
            text = "Login Huawei"
            setOnClickListener { loginHuawei() }
        }
        page.addView(loginButton)
        status = label("Status: belum diuji", 14, Color.DKGRAY).apply { setPadding(0, 20, 0, 0) }
        page.addView(status)
        page.addView(label("Tahap pengembangan", 17, Color.BLACK, true).apply { setPadding(0, 26, 0, 8) })
        page.addView(label("✓ Deteksi gateway dan input IP\n✓ Uji respons halaman router\n◐ Percobaan autentikasi Huawei legacy\n○ Membaca SSID dan password WiFi\n○ Daftar perangkat terhubung\n○ Pengaturan WiFi dan restart", 13, Color.DKGRAY))
        page.addView(label("Catatan: firmware ISP dapat mengubah endpoint atau menonaktifkan API. Login perlu diuji pada unit HG8145V5 yang sebenarnya sebelum fitur konfigurasi diaktifkan.", 12, Color.GRAY).apply { setPadding(0, 20, 0, 0) })
        setContentView(scroll)
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
    }

    private fun input(hintText: String) = EditText(this).apply {
        hint = hintText
        textSize = 16f
        singleLine = true
        setPadding(16, 12, 16, 12)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 10 }
    }

    @Suppress("DEPRECATION")
    private fun detectGateway(): String = try {
        val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val ip = wifi.dhcpInfo.gateway
        if (ip == 0) "" else listOf(0, 8, 16, 24).joinToString(".") { ((ip shr it) and 0xff).toString() }
    } catch (_: Exception) { "" }

    private fun testConnection() {
        val host = normalizedHost()
        if (!isValidHost(host)) { showStatus("Masukkan alamat IP atau host router yang valid."); return }
        showStatus("Menguji koneksi ke $host ...")
        worker.execute {
            val result = try {
                val address = InetAddress.getByName(host)
                if (!address.isSiteLocalAddress && !address.isLoopbackAddress) throw IllegalArgumentException("Gunakan alamat lokal router")
                val connection = (URL("http://$host/").openConnection() as HttpURLConnection).apply {
                    connectTimeout = 5000; readTimeout = 5000; requestMethod = "GET"; instanceFollowRedirects = false
                }
                val code = connection.responseCode
                connection.disconnect()
                "Router memberi respons HTTP $code. Ini hanya tes jaringan, bukan bukti login berhasil."
            } catch (e: Exception) { "Koneksi gagal: ${e.message ?: e.javaClass.simpleName}. Periksa WiFi dan alamat router." }
            runOnUiThread { showStatus(result) }
        }
    }

    private fun loginHuawei() {
        val host = normalizedHost()
        val user = usernameField.text.toString().trim()
        val pass = passwordField.text.toString()
        if (!isValidHost(host) || user.isBlank() || pass.isBlank()) {
            showStatus("Isi IP router, username, dan password terlebih dahulu."); return
        }
        loginButton.isEnabled = false
        showStatus("Mengambil token dan mencoba login Huawei...")
        worker.execute {
            val client = HuaweiLegacyClient(host)
            val result = client.login(user, pass)
            val extra = if (result.success) "\n\nPembacaan WLAN (read-only):\n${client.readWifiSettings().summary}" else ""
            runOnUiThread {
                loginButton.isEnabled = true
                showStatus(result.message + extra)
            }
        }
    }

    private fun normalizedHost(): String = ipField.text.toString().trim().removePrefix("http://").removePrefix("https://").trimEnd('/')
    private fun isValidHost(host: String): Boolean = host.isNotBlank() && !host.contains('/') && !host.contains(' ') && !host.contains(':')
    private fun showStatus(message: String) { status.text = "Status: $message" }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }
}
