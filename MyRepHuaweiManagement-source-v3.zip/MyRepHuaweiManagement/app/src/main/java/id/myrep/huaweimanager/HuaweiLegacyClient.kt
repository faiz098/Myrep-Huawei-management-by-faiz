package id.myrep.huaweimanager

import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.CookieManager
import java.net.CookieHandler
import java.net.CookiePolicy
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import android.util.Base64

/**
 * Client for the legacy Huawei ONT web interface family.
 * The login flow is based on observed HG8145V5/EG8145V5 firmware implementations.
 * ISP-customized firmware may use a different flow or disable these endpoints.
 */
class HuaweiLegacyClient(hostInput: String) {
    private val host = hostInput.trim().removePrefix("http://").removePrefix("https://").trimEnd('/')
    private val base = "http://$host"
    private val cookies = CookieManager(null, CookiePolicy.ACCEPT_ALL)
    private var sessionToken: String? = null

    init {
        // HttpURLConnection uses CookieHandler to persist the router session cookie.
        CookieHandler.setDefault(cookies)
    }

    data class LoginResult(val success: Boolean, val message: String)

    fun login(username: String, password: String): LoginResult {
        if (host.isBlank() || username.isBlank() || password.isBlank()) {
            return LoginResult(false, "IP, username, dan password wajib diisi.")
        }
        return try {
            // Fetch one-time anti-replay token before submitting credentials.
            val tokenResponse = request("/asp/GetRandCount.asp", "POST", "", includeAnonymousCookie = true)
            val token = tokenResponse.body.removePrefix("\uFEFF").trim()
            if (token.isBlank() || token.length > 256 || token.contains('<')) {
                return LoginResult(false, "Router tidak memberikan token login yang dikenali. Firmware mungkin berbeda.")
            }

            val encodedPassword = Base64.encodeToString(password.toByteArray(StandardCharsets.UTF_8), Base64.NO_WRAP)
            val form = listOf(
                "UserName" to username,
                "PassWord" to encodedPassword,
                "Language" to "english",
                "x.X_HW_Token" to token
            ).joinToString("&") { (k, v) -> enc(k) + "=" + enc(v) }

            val loginResponse = request("/login.cgi", "POST", form, includeAnonymousCookie = true)
            // Huawei firmware commonly stores its session in a cookie named "Cookie"
            // whose value contains sid=... . Some builds use a direct sid cookie.
            val sessionCookie = cookies.cookieStore.cookies.any { cookie ->
                val value = cookie.value
                (cookie.name.equals("Cookie", true) && value.contains("sid=", true) &&
                    !value.contains("id=-1", true)) ||
                    (cookie.name.equals("sid", true) && value.isNotBlank())
            }

            if (sessionCookie) {
                sessionToken = try {
                    request("/html/ssmp/common/GetRandToken.asp", "GET", null, includeAnonymousCookie = false)
                        .body.removePrefix("\uFEFF").trim().takeIf { it.isNotBlank() && !it.contains('<') }
                } catch (_: Exception) { null }
                LoginResult(true, if (sessionToken != null) "Login diterima router. Cookie sesi dan token autentikasi diperoleh." else "Cookie sesi diterima router. Token lanjutan belum terdeteksi; firmware mungkin berbeda.")
            } else {
                val body = loginResponse.body.lowercase()
                if (body.contains("wrong password") || body.contains("invalid") || body.contains("login failed")) {
                    LoginResult(false, "Router menolak login. Periksa username/password.")
                } else {
                    LoginResult(false, "Belum terverifikasi: router tidak mengirim cookie sesi yang dikenali. Periksa firmware atau metode login.")
                }
            }
        } catch (e: Exception) {
            LoginResult(false, "Gagal login: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    data class WifiReadResult(val summary: String, val ssids: List<String>, val passwordFields: List<String>)

    /** Read-only page inspection. Values are reported only when present in returned HTML. */
    fun readWifiSettings(): WifiReadResult {
        val candidates = listOf(
            "/html/bbsp/wlan/wlanbasic.asp",
            "/html/amp/wlanbasic/wlan.asp",
            "/html/amp/wlanbasic/WlanBasic.asp",
            "/html/bbsp/wlan/wlan.asp"
        )
        val ssids = linkedSetOf<String>()
        val passwords = linkedSetOf<String>()
        val details = candidates.map { path ->
            try {
                val r = request(path, "GET", null, includeAnonymousCookie = false)
                if (r.code in 200..299 && !looksLikeLoginPage(r.body)) {
                    // Firmware pages often render WLAN values in HTML input attributes.
                    val inputs = Regex("(?is)<input\\b[^>]*>").findAll(r.body).map { it.value }
                    for (tag in inputs) {
                        val name = attr(tag, "name") ?: attr(tag, "id") ?: continue
                        val value = attr(tag, "value") ?: continue
                        val key = name.lowercase()
                        if (key.contains("ssid") && value.isNotBlank()) ssids.add("$name = $value")
                        if ((key.contains("wpa") || key.contains("pre_shared") || key.contains("keypass")) && value.isNotBlank()) {
                            passwords.add("$name = $value")
                        }
                    }
                }
                val preview = r.body.replace(Regex("\\s+"), " ").take(100)
                "$path -> HTTP ${r.code}, ${r.body.length} karakter, $preview"
            } catch (e: Exception) {
                "$path -> ${e.javaClass.simpleName}"
            }
        }
        val summary = buildString {
            append(details.joinToString("\n"))
            append("\n\nSSID terdeteksi dari HTML: ")
            append(if (ssids.isEmpty()) "belum ditemukan" else ssids.joinToString("; "))
            append("\nField password terdeteksi: ")
            append(if (passwords.isEmpty()) "belum ditemukan / disembunyikan firmware" else passwords.joinToString("; "))
        }
        return WifiReadResult(summary, ssids.toList(), passwords.toList())
    }

    private fun looksLikeLoginPage(html: String): Boolean =
        html.contains("login.cgi", true) || html.contains("name=\"username\"", true) ||
            html.contains("name=\"password\"", true)

    private fun attr(tag: String, key: String): String? {
        val regex = Regex("(?is)\\b${Regex.escape(key)}\\s*=\\s*(['\"])(.*?)\\1")
        return regex.find(tag)?.groupValues?.get(2)
    }

    private data class HttpResult(val code: Int, val body: String)

    private fun request(path: String, method: String, data: String?, includeAnonymousCookie: Boolean): HttpResult {
        val connection = (URL(base + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 7000
            readTimeout = 7000
            instanceFollowRedirects = false
            useCaches = false
            setRequestProperty("Accept", "*/*")
            setRequestProperty("User-Agent", "Mozilla/5.0 Android MyRepHuaweiManager")
            if (includeAnonymousCookie && cookies.cookieStore.cookies.isEmpty()) {
                setRequestProperty("Cookie", "Cookie=body:Language:english:id=-1")
            }
            if (data != null) {
                doOutput = true
                setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
            }
        }
        try {
            if (data != null) connection.outputStream.use { it.write(data.toByteArray(StandardCharsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code >= 400) connection.errorStream else connection.inputStream
            val body = stream?.use { input -> BufferedReader(InputStreamReader(input, StandardCharsets.UTF_8)).readText() } ?: ""
            return HttpResult(code, body)
        } finally {
            connection.disconnect()
        }
    }

    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")
}
