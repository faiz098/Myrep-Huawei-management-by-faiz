# MyRep Huawei Management

Android starter project for local Huawei router connectivity checks.

## Current status
- Android Kotlin project structure created.
- Gateway IP auto-detection and manual IP entry included.
- HTTP reachability check included.
- Router authentication and configuration are not implemented yet; Huawei APIs vary by model and firmware.

## Build
Run `gradle assembleDebug` with JDK 17 and Android SDK installed. GitHub Actions workflow is included for automated APK builds.
