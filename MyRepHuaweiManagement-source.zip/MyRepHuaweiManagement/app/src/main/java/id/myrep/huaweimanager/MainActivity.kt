package id.myrep.huaweimanager

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.net.wifi.WifiManager
import android.graphics.Color
import android.view.ViewGroup
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var ipField: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(76, 29, 149)
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 28, 24, 24); setBackgroundColor(Color.rgb(248, 247, 252)) }
        val scroll = ScrollView(this).apply { addView(page) }
        page.addView(label("MYREP HUAWEI MANAGEMENT", 23, Color.rgb(76, 29, 149), true))
        page.addView(label("Kelola router Huawei melalui jaringan WiFi lokal.", 14, Color.DKGRAY))
        page.addView(label("Koneksi router", 19, Color.BLACK, true).apply { setPadding(0, 30, 0, 12) })
        ipField = input("IP router, contoh 192.168.18.1").apply { setText(detectGateway()) }
        page.addView(ipField)
        page.addView(Button(this).apply { text = "Deteksi gateway"; setOnClickListener { val ip = detectGateway(); if (ip.isNotBlank()) ipField.setText(ip) else showStatus("Gateway tidak terdeteksi. Pastikan HP tersambung ke WiFi router.") } })
        page.addView(label("Login router", 19, Color.BLACK, true).apply { setPadding(0, 24, 0, 12) })
        page.addView(input("Username"))
        page.addView(input("Password").apply { inputType = 129 })
        page.addView(Button(this).apply { text = "Uji koneksi router"; setOnClickListener { testConnection() } })
        status = label("Status: belum diuji", 14, Color.DKGRAY).apply { setPadding(0, 20, 0, 0) }
        page.addView(status)
        page.addView(label("Tahap awal hanya menguji akses jaringan ke halaman router. Autentikasi dan pengaturan WiFi belum diimplementasikan karena API login berbeda menurut model dan firmware.", 13, Color.GRAY).apply { setPadding(0, 24, 0, 0) })
        setContentView(scroll)
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
    }
    private fun input(hintText: String) = EditText(this).apply {
        hint = hintText; textSize = 16f; singleLine = true; setPadding(16, 12, 16, 12)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 10 }
    }
    @Suppress("DEPRECATION")
    private fun detectGateway(): String = try {
        val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val ip = wifi.dhcpInfo.gateway
        if (ip == 0) "" else listOf(0, 8, 16, 24).joinToString(".") { ((ip shr it) and 0xff).toString() }
    } catch (_: Exception) { "" }

    private fun testConnection() {
        val host = ipField.text.toString().trim().removePrefix("http://").removeSuffix("/")
        if (host.isBlank()) { showStatus("Masukkan IP router terlebih dahulu."); return }
        showStatus("Menguji koneksi ke $host ...")
        worker.execute {
            val result = try {
                val conn = (URL("http://$host/").openConnection() as HttpURLConnection).apply { connectTimeout = 5000; readTimeout = 5000; requestMethod = "GET"; instanceFollowRedirects = false }
                val code = conn.responseCode; conn.disconnect()
                "Router merespons. HTTP $code. Ini belum berarti login berhasil."
            } catch (e: Exception) { "Gagal mengakses router: ${e.javaClass.simpleName}. Periksa WiFi dan IP." }
            runOnUiThread { showStatus(result) }
        }
    }
    private fun showStatus(message: String) { status.text = "Status: $message" }
    override fun onDestroy() { worker.shutdown(); super.onDestroy() }
}
